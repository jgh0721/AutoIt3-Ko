Note: Many of the examples in this directory will only work correctly
on systems with English versions of Windows installed.  They will
require modification for use with other Windows versions.

- Jon.
